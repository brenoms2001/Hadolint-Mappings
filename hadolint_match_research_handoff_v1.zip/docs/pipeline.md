# Research Pipeline

## Conceptual pipeline

```text
Source rule acquisition
        ↓
Structured Hadolint/ShellCheck dataset
        ↓
IEC 62443-3-3 extraction / enrichment
        ↓
Embedding generation
        ↓
Cosine similarity
        ↓
Clamp negatives to zero
        ↓
Power transform (5.5)
        ↓
Per-source L-infinity normalization
        ↓
Relative threshold (0.68)
        ↓
Top-K (10)
        ↓
Canonical candidate dataset (4134 pairs)
        ↓
Gemini preliminary pair audit
        ↓
Human pair annotation
        ↓
Gold-standard analyses
```

Auxiliary branch:

```text
594 source rules
        ↓
Independent LLM-assisted security-relevance classification
        ↓
security_related / non_security / uncertain
        ↓
Rule-level exploratory cross-analysis with preliminary pair audit
        ↓
Optional independent author validation
```

The auxiliary branch must not feed back into candidate generation.

## Current verified checkpoints

### Candidate generation
- 594 source rules
- 4134 candidate associations
- threshold = 0.68
- top_k = 10
- power = 5.5

### Preliminary Gemini pair audit
- 4134 results
- YES = 78
- MAYBE = 481
- NO = 3575

### Preliminary security relevance
- security_related = 86
- non_security = 504
- uncertain = 4

## Repository-audit goal

The next migration task is to map real repository files to each stage above without changing scientific behavior.
