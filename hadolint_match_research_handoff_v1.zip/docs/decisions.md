# Methodological Decisions

This file records decisions that agents must not silently reinterpret.

## D001 — Gemini pair audit is preliminary

Gemini evaluates candidate associations before human review.

Its verdicts are not gold-standard labels.

Human review remains authoritative.

## D002 — Security relevance is independent

The security-relevance classification is a rule-level auxiliary analysis.

It does not alter the canonical matching pipeline.

## D003 — Do not filter non-security rules

Rules classified as `non_security` remain part of the candidate universe and research analysis.

Security relevance is not a candidate-generation filter.

## D004 — Human pair labels

Human pair annotation uses:

- `relevant`
- `partially_relevant`
- `irrelevant`

Human confidence uses a 1–5 scale.

Notes are optional.

## D005 — Security-relevance human validation is a separate task

If security relevance is validated by an author, it should be treated separately from pair-level gold-standard annotation.

Prefer an independent review in which the human reviewer does not see the Gemini security-relevance label before deciding, to reduce anchoring.

## D006 — Preliminary security labels must be named honestly

Until human validation is completed, paper text and artifacts should identify the classification as LLM-assisted or preliminary.

Avoid wording that presents the 86/504/4 split as an author-established ground truth.

## D007 — Candidate generation remains canonical

Do not change:

- embedding model
- cosine similarity
- negative clamp
- exponent 5.5
- per-source L-infinity normalization
- threshold 0.68
- top-K 10

without explicit methodological authorization.

## D008 — Preserve full Gemini results

Even if human review is prioritized using Gemini results, the complete preliminary audit should be preserved for analysis.

## D009 — Human labels do not automatically transfer across matching configurations

Human judgments apply to the candidate associations/configuration actually reviewed.

Changing matching methodology may require a new validation decision.

## D010 — Research cleanup must not rewrite history

Old or intermediate artifacts may be important for traceability.

A cleanup agent must distinguish:
- redundant temporary files;
- superseded but historically relevant artifacts;
- canonical artifacts.

Uncertainty means preserve and request manual review.
